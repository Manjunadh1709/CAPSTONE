export class Aadhar{
    name!: string;
    dob!: string;
    gender!: string;
    mobilenumber!: string;
    aadharnumber!: string;
    housenumber!: string;
    street!: string;
    district!: string;
    state!: string;
    pincode!: string;
}