export class User {
    name : string = '';
    username!: string;
    password : string;
    role!: string ;
    token!: string;
    email!: string;
    mobile!: any;
}